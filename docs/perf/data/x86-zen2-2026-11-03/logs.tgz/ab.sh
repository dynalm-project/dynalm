#!/bin/sh
B=/root/dynalm-spec/build/linux-release/bin/dynalm
for i in 1 2; do for c in 1 0; do echo -n "cost=$c: "; DYNALM_SPEC_COST_AWARE=$c $B benchmark $HOME/.dynalm/models/Qwen3-4B-Q4_K_M.gguf --mode exact -t 4 --concurrency 1 --prompt 512 --output 128 --warmup-requests 1 --spec-eagle $HOME/.dynalm/eagle/Qwen3-4B_eagle3 --spec-k 3 2>&1 | grep -E "^ +1 +512|->" | tr -s " " | cut -d"|" -f5,6 | tr "\n" " "; echo; done; done
echo done > /root/ab.done
