#!/bin/sh
# Decode-kernel accuracy A/B: fp32 reference, then main and new int8 kernels one token per batch.
M=$HOME/.dynalm/models/qwen2.5-1.5b-instruct-q4_k_m.gguf
W=$HOME/.dynalm/cpu-report/wikitext/wikitext-2-raw/wiki.test.raw
N=/root/dynalm-x86/build/linux-release/dynalm/benchmarks/bench_ppl
B=/root/dynalm-base/build/linux-release/dynalm/benchmarks/bench_ppl
cd /root
BENCH_UBATCH=1 BENCH_INT8_ROWS=0 BENCH_KLD_BASE=/root/ref.kld $N $M $W 512 6 4 > /root/acc-ref.log 2>&1
BENCH_UBATCH=1 BENCH_KLD_REF=/root/ref.kld $B $M $W 512 6 4 > /root/acc-main.log 2>&1
BENCH_UBATCH=1 BENCH_KLD_REF=/root/ref.kld $N $M $W 512 6 4 > /root/acc-new.log 2>&1
echo done > /root/acc.done
