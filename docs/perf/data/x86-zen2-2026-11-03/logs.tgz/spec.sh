#!/bin/sh
B=/root/dynalm-x86/build/linux-release/bin/dynalm
M=$HOME/.dynalm/models/qwen2.5-1.5b-instruct-q4_k_m.gguf
D=$HOME/.dynalm/models/qwen2.5-0.5b-instruct-q4_k_m.gguf
run() { echo "== $1"; shift; $B benchmark $M --mode exact -t 4 --concurrency 1 --prompt 512 --output 128 --warmup-requests 1 "$@" 2>&1 | grep -E "^ +1 +512|->|accept|spec" ; }
run none
run draft-k2 --spec $D --spec-k 2
run draft-k4 --spec $D --spec-k 4
run ngram-k4 --spec ngram --spec-k 4
echo done
