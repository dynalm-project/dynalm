#!/bin/sh
B=/root/dynalm-spec/build/linux-release/bin/dynalm
for m in 8B 4B; do
for c in "0 32" "1 32" "1 4" "0 4"; do
  set -- $c
  rm -f /root/sp.json
  echo -n "$m cost=$1 probe=$2: "
  DYNALM_SPEC_COST_AWARE=$1 DYNALM_SPEC_PROBE_STEPS=$2 $B benchmark $HOME/.dynalm/models/Qwen3-$m-Q4_K_M.gguf --mode exact -t 4 --concurrency 1 --prompt 128 --output 128 --requests 2 --no-diag --spec-eagle $HOME/.dynalm/eagle/Qwen3-${m}_eagle3 --spec-k 3 --out /root/sp.json 2>&1 | grep -E "^ +1 +128" | tr -s " " | cut -d"|" -f2,5 | tr "\n" " "
  python3 -c "import json; d=json.loads(open(\"/root/sp.json\").readline()); print(\"drafted\",d.get(\"spec_drafted\"),\"accepted\",d.get(\"spec_accepted\"))"
done; done
echo done > /root/sp.done
