#!/bin/sh
# Before/after, cpu-report workload, --mode exact; builds alternate per model.
for m in qwen2.5-1.5b-instruct-q4_k_m Qwen3-4B-Q4_K_M Qwen3-8B-Q4_K_M; do
  for b in base x86; do
    /root/dynalm-$b/build/linux-release/bin/dynalm benchmark $HOME/.dynalm/models/$m.gguf --mode exact -t 4 --concurrency 1,4 --prompt 512 --output 128 --warmup-requests 1 > /root/final-$m-$b.log 2>&1
  done
done
echo done > /root/final.done
