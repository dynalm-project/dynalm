#!/bin/sh
B=/root/dynalm-spec/build/linux-release/bin/dynalm
M=$HOME/.dynalm/models/Qwen3-4B-Q4_K_M.gguf
E=$HOME/.dynalm/eagle/Qwen3-4B_eagle3
for c in "3 0" "4 0" "4 1" "5 1" "3 0"; do
  set -- $c
  echo -n "k=$1 packed8=$2: "
  DYNACORE_PACKED_8ROWS=$2 $B benchmark $M --mode exact -t 4 --concurrency 1 --prompt 512 --output 128 --warmup-requests 1 --spec-eagle $E --spec-k $1 2>&1 | grep -E "^ +1 +512|->" | tr -s " " | cut -c1-170 | tr "\n" " "; echo
done
echo done > /root/e8.done
