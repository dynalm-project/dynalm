#!/bin/sh
# llama.cpp (llama-server, CPU, 4 threads) on the same workload as the DynaLM runs.
L=/root/.dynalm/cpu-report/llama-b11695/llama-b11695
export LD_LIBRARY_PATH=$L
for m in qwen2.5-1.5b-instruct-q4_k_m Qwen3-4B-Q4_K_M Qwen3-8B-Q4_K_M; do
  $L/llama-server -m $HOME/.dynalm/models/$m.gguf --port 18901 -c 4096 -np 4 -ngl 0 -t 4 > /root/llama-srv-$m.log 2>&1 &
  P=$!
  for i in $(seq 1 120); do curl -sf http://127.0.0.1:18901/health >/dev/null && break; sleep 1; done
  /root/dynalm-x86/build/linux-release/bin/dynalm benchmark $HOME/.dynalm/models/$m.gguf --url http://127.0.0.1:18901 --model-name $m --concurrency 1,4 --prompt 512 --output 128 --warmup-requests 1 > /root/final-$m-llama.log 2>&1
  kill $P; wait $P 2>/dev/null
done
echo done > /root/llama.done
