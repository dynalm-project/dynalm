#!/bin/sh
L=/root/.dynalm/cpu-report/llama-b11695/llama-b11695
B=/root/dynalm-spec/build/linux-release/bin/dynalm
M=$HOME/.dynalm/models/Qwen3-4B-Q4_K_M.gguf
E=$HOME/.dynalm/eagle/Qwen3-4B_eagle3
W="--concurrency 1 --prompt 512 --output 128 --warmup-requests 1"
LD_LIBRARY_PATH=$L $L/llama-server -m $M --port 18901 -c 4096 -np 4 -ngl 0 -t 4 > /root/llama-srv.log 2>&1 &
P=$!
for i in $(seq 1 120); do curl -sf http://127.0.0.1:18901/health >/dev/null && break; sleep 1; done
echo "== llama.cpp"; $B benchmark $M --url http://127.0.0.1:18901 --model-name q $W 2>&1 | grep -E "^ +1 +512"
kill $P; wait $P 2>/dev/null
echo "== dynalm none"; $B benchmark $M --mode exact -t 4 $W 2>&1 | grep -E "^ +1 +512"
echo "== dynalm eagle k3"; $B benchmark $M --mode exact -t 4 $W --spec-eagle $E --spec-k 3 2>&1 | grep -E "^ +1 +512"
echo done > /root/cmp4b.done
