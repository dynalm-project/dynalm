#!/bin/sh
B=/root/dynalm-spec/build/linux-release/bin/dynalm
M=$HOME/.dynalm/models/Qwen3-4B-Q4_K_M.gguf
E=$HOME/.dynalm/eagle/Qwen3-4B_eagle3
run() { echo "== $1"; shift; $B benchmark $M --mode exact -t 4 --concurrency 1 --prompt 512 --output 128 --warmup-requests 1 "$@" > /root/eagle-cur.log 2>&1; grep -E "^ +1 +512|->|eagle|draft|accept" /root/eagle-cur.log | head -6; }
#run none
run e1 --spec-eagle $E --spec-k 1
run e2 --spec-eagle $E --spec-k 2
run e3 --spec-eagle $E --spec-k 3
#run e4 --spec-eagle $E --spec-k 4
echo done > /root/eagle.done
