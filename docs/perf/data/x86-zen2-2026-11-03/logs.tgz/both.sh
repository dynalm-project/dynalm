#!/bin/sh
/root/cmp4b.sh > /root/cmp4b.out 2>&1
/root/cmp8b.sh > /root/cmp8b.out 2>&1
echo done > /root/both.done
