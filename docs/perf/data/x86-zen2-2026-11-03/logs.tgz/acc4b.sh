#!/bin/sh
M=$HOME/.dynalm/models/Qwen3-4B-Q4_K_M.gguf
W=$HOME/.dynalm/cpu-report/wikitext/wikitext-2-raw/wiki.test.raw
N=/root/bench_ppl_new
B=/root/dynalm-base/build/linux-release/dynalm/benchmarks/bench_ppl
cd /root
BENCH_UBATCH=1 BENCH_INT8_ROWS=0 BENCH_KLD_BASE=/root/ref4b.kld $N $M $W 512 3 4 > /root/acc4b-ref.log 2>&1
BENCH_UBATCH=1 BENCH_KLD_REF=/root/ref4b.kld $B $M $W 512 3 4 > /root/acc4b-main.log 2>&1
DYNACORE_INT8_SUBSCALE=1 BENCH_UBATCH=1 BENCH_KLD_REF=/root/ref4b.kld $N $M $W 512 3 4 > /root/acc4b-sx.log 2>&1
echo done > /root/acc4b.done
